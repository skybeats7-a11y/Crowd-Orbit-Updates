'use strict';
(() => {
  const KEY='crowd_orbit_offline_v1';
  const clamp=(n,min,max)=>Math.max(min,Math.min(max,Number(n)||0));
  const now=()=>new Date().toISOString();
  const blank=()=>({version:3,nextPersonId:1,nextSeedId:1,nextCampaignId:1,nextInteractionId:1,people:[],seeds:[],campaigns:[],campaignPeople:[],interactions:[],goals:['Find Clients','Find Collaborators','Build Industry Relationships']});
  const arr=v=>Array.isArray(v)?v:[];
  const text=v=>String(v??'').trim();
  const lower=v=>text(v).toLowerCase();

  function load(){
    try{
      const raw=localStorage.getItem(KEY); if(!raw)return blank();
      const d=JSON.parse(raw); if(!d)return blank();
      const out={...blank(),...d};
      out.version=3;out.people=arr(d.people);out.seeds=arr(d.seeds);out.campaigns=arr(d.campaigns);out.campaignPeople=arr(d.campaignPeople);out.interactions=arr(d.interactions);out.goals=arr(d.goals).length?arr(d.goals):blank().goals;
      out.people=out.people.map(p=>({...p,phone_number:text(p.phone_number||p.phone||''),analysis_status:p.analysis_status||'Imported',analysis_confidence:Number(p.analysis_confidence||p.classification_confidence||0),last_analysed_at:p.last_analysed_at||''}));
      return out;
    }catch{return blank()}
  }
  let db=load(); save();
  function save(){localStorage.setItem(KEY,JSON.stringify(db));}
  function body(opts){try{return opts&&opts.body?JSON.parse(opts.body):{}}catch{return {}}}
  function daysSince(v){if(!v)return 999;const n=(Date.now()-new Date(v).getTime())/86400000;return Number.isFinite(n)?Math.max(0,Math.floor(n)):999}
  function cleanEmail(v){v=lower(v);return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)?v:''}
  function cleanPhone(v){
    let s=text(v);if(!s)return'';s=s.replace(/[^\d+() .-]/g,'').trim();
    const digits=s.replace(/\D/g,'');if(digits.length<7||digits.length>16)return'';
    if(s.startsWith('00'))s='+'+s.slice(2);return s.replace(/\s+/g,' ').slice(0,40);
  }
  function humanHandle(h){return text(h).replace(/^@/,'').replace(/[._-]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase()).trim()||'Captured profile'}
  function social(url){
    try{
      const u=new URL(url),host=u.hostname.toLowerCase(),parts=u.pathname.split('/').filter(Boolean);let platform='',handle='';
      if(host.includes('instagram.com')){platform='Instagram';handle=parts[0]||''}
      else if(host.includes('tiktok.com')){platform='TikTok';handle=(parts.find(x=>x.startsWith('@'))||parts[0]||'').replace(/^@/,'')}
      else if(host==='x.com'||host.includes('twitter.com')){platform='X';handle=parts[0]||''}
      else if(host.includes('youtube.com')){platform='YouTube';let first=parts[0]||'';if(first.startsWith('@'))handle=first.slice(1);else if(['channel','c','user'].includes(first.toLowerCase()))handle=parts[1]||''}
      else if(host.includes('soundcloud.com')){platform='SoundCloud';handle=parts[0]||''}
      else if(host.includes('spotify.com')){platform='Spotify';handle=parts.at(-1)||''}
      else if(host.includes('linkedin.com')){platform='LinkedIn';handle=parts.at(-1)||''}
      else return null;
      return {platform,handle:handle?'@'+handle.replace(/^@/,''):'',url:u.href};
    }catch{return null}
  }
  const ROLE_RULES=[
    ['A&R',/\b(a\s*&\s*r|artists?\s+and\s+repertoire)\b/i],
    ['Engineer',/\b(audio engineer|sound engineer|mix(?:ing)? engineer|mastering engineer|mix(?:ing)?\s*&?\s*master(?:ing)?)\b/i],
    ['Producer',/\b(music producer|record producer|beatmaker|beat maker|producer|beats? by)\b/i],
    ['Songwriter',/\b(songwriter|song writer|composer|lyricist)\b/i],
    ['Manager',/\b(artist manager|music manager|management|manager)\b/i],
    ['DJ',/\b(dj|disc jockey)\b/i],
    ['Label',/\b(record label|indie label|label owner|label)\b/i],
    ['Media',/\b(journalist|editor|radio host|presenter|podcast host|media|blogger|press)\b/i],
    ['Artist',/\b(artist|rapper|singer|vocalist|musician|recording artist|mc\b)\b/i]
  ];
  function inferRole(s){for(const [role,re] of ROLE_RULES){if(re.test(s))return role}return'Unknown'}
  function inferLocation(s){const places=['London','Birmingham','Manchester','Leeds','Liverpool','Bristol','Glasgow','Cardiff','New York','Los Angeles','Atlanta','Toronto','Paris','Berlin'];return places.find(p=>new RegExp(`\\b${p.replace(/ /g,'\\s+')}\\b`,'i').test(s))||''}
  function inferFollowers(s){
    const m=String(s).match(/(?:followers?|fans?|audience)\s*[:\-]?\s*([\d,.]+)\s*([km]?)/i)||String(s).match(/([\d,.]+)\s*([km]?)\s*(?:followers?|fans?)/i);if(!m)return 0;
    let n=Number(String(m[1]).replace(/,/g,''))||0;const suffix=lower(m[2]);if(suffix==='k')n*=1000;if(suffix==='m')n*=1000000;return Math.round(n);
  }
  function inferEmail(s){const m=String(s).match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);return cleanEmail(m?.[0]||'')}
  function inferPhone(s){
    const candidates=String(s).match(/(?:\+|00)?\d[\d\s().-]{6,}\d/g)||[];
    for(const c of candidates){const p=cleanPhone(c);if(p)return p}return'';
  }
  function inferUrl(s){return (String(s).match(/https?:\/\/[^\s,;]+/i)||[])[0]||''}
  function inferHandle(s){const direct=(String(s).match(/(^|[\s,(])@([A-Za-z0-9._-]{2,})/)||[])[2];if(direct)return'@'+direct;const u=inferUrl(s),p=social(u);return p?.handle||''}
  function inferName(s,handle,url){
    const first=String(s).split(/[|,;\t]/)[0].trim();
    if(first&&!/^https?:\/\//i.test(first)&&!first.startsWith('@')&&!/\b(email|phone|followers?)\b/i.test(first)&&first.length<=90)return first;
    if(handle)return humanHandle(handle);
    if(url){const p=social(url);if(p?.handle)return humanHandle(p.handle);try{return humanHandle(new URL(url).pathname.split('/').filter(Boolean).at(-1)||'Captured profile')}catch{}}
    return'Captured profile';
  }
  function analyseTextLine(line){
    const raw=text(line);if(!raw)return null;const url=inferUrl(raw),sp=social(url),handle=inferHandle(raw),email=inferEmail(raw),phone=inferPhone(raw),role=inferRole(raw),loc=inferLocation(raw),followers=inferFollowers(raw);
    const name=inferName(raw,handle,url);let confidence=20;if(handle)confidence+=18;if(url)confidence+=12;if(role!=='Unknown')confidence+=20;if(email)confidence+=15;if(phone)confidence+=15;if(loc)confidence+=5;if(followers)confidence+=5;
    const status=(email||phone||url)?'Contact Ready':'Missing Details';
    return {name,handle,role,location:loc,followers,relationship:'Discovery',contact_email:email,phone_number:phone,source_url:url,platforms:sp?.platform?[sp.platform]:[],notes:raw.slice(0,3000),analysis_status:status,analysis_confidence:clamp(confidence,0,100),last_analysed_at:now(),classification_confidence:role==='Unknown'?0:clamp(confidence,0,100)};
  }
  function mergeField(oldVal,newVal){if(Array.isArray(newVal))return newVal.length?Array.from(new Set([...(Array.isArray(oldVal)?oldVal:[]),...newVal])):oldVal;if(newVal===undefined||newVal===null||newVal==='')return oldVal;return newVal}
  function personView(p){
    const ints=db.interactions.filter(i=>i.person_id===p.id).sort((a,b)=>String(b.at).localeCompare(String(a.at)));const last=ints[0]?.at||p.last_interaction||'';const trend=daysSince(last)<=7?'Getting closer':daysSince(last)>=30?'Cooling':'Stable';
    const hasContact=Boolean(p.contact_email||p.phone_number||p.website||p.source_url);const computed=opportunityScore(p);let analysisStatus=p.analysis_status||'Imported';if(computed>=78&&hasContact)analysisStatus='Priority';else if(hasContact&&analysisStatus!=='Priority')analysisStatus='Contact Ready';else if(!hasContact&&analysisStatus==='Imported')analysisStatus='Missing Details';
    return {...p,secondary_roles:arr(p.secondary_roles),platforms:arr(p.platforms),source_accounts:arr(p.source_accounts),has_contact:hasContact,last_interaction:last,relationship_trend:trend,interaction_count:ints.length,phone_number:text(p.phone_number),analysis_status:analysisStatus,opportunity_score:computed};
  }
  function opportunityScore(p){
    let s=Number(p.network_score||50),role=text(p.role),followers=Number(p.followers||0),contact=Boolean(p.contact_email||p.phone_number||p.website||p.source_url);if(role&&role!=='Unknown')s+=8;if(contact)s+=10;if(p.contact_email)s+=4;if(p.phone_number)s+=4;if(p.relationship==='Warm')s+=12;else if(p.relationship==='2nd degree')s+=6;s+=Math.min(8,Number(p.source_overlap||0)*1.5);s+=Math.min(8,Math.log10(Math.max(1,followers))*1.8);s+=Math.min(6,Number(p.analysis_confidence||0)/20);return Math.round(clamp(s,0,100));
  }
  function score(p,goal='general',priority='best_overall'){
    let s=opportunityScore(p),role=lower(p.role),rel=p.relationship,followers=Number(p.followers||0),contact=Boolean(p.contact_email||p.phone_number||p.website||p.source_url);
    const boosts={recruit_artists:role==='artist'?18:role==='manager'?7:0,studio_services:['artist','producer','manager'].includes(role)?14:role==='engineer'?5:0,release_promo:['dj','manager','media'].includes(role)?14:role==='artist'?7:0,relationships:['manager','producer','engineer','dj','a&r','label'].includes(role)?12:6,collaborators:['producer','engineer','artist','songwriter'].includes(role)?14:0,general:0};
    s+=(boosts[goal]||0);if(priority==='warm_first'&&rel==='Warm')s+=16;if(priority==='largest_first')s+=Math.min(18,Math.log10(Math.max(1,followers))*4);if(priority==='contacts_first'&&contact)s+=18;if(priority==='new_first'&&rel==='Discovery')s+=16;return Math.round(clamp(s,0,100));
  }
  function reason(p,goal){const bits=[];if(p.relationship==='Warm')bits.push('already in your Inner Orbit');else if(p.relationship==='2nd degree')bits.push('within your extended orbit');else bits.push('a new discovery opportunity');if(Number(p.source_overlap||0)>=3)bits.push(`overlaps ${p.source_overlap} audience sources`);if(p.contact_email||p.phone_number)bits.push('has direct contact data');else if(p.source_url||p.website)bits.push('has a profile/contact route');if(Number(p.followers||0)>=10000)bits.push('has meaningful audience reach');if(goal==='recruit_artists'&&lower(p.role)==='artist')bits.unshift('matches artist recruitment');return bits.slice(0,4).join(', ')+'.'}
  function filters(q){return {search:lower(q.get('search')||''),role:q.get('role')||'',relationship:q.get('relationship')||'',location:q.get('location')||'',hasContact:q.get('hasContact')==='1',minFollowers:Number(q.get('minFollowers')||0),analysisStatus:q.get('analysisStatus')||''}}
  function filterPeople(rows,f){return rows.map(personView).filter(p=>{if(f.role&&f.role!=='Any'&&f.role!=='All roles'&&p.role!==f.role)return false;if(f.relationship&&f.relationship!=='Any'&&p.relationship!==f.relationship)return false;if(f.location&&f.location!=='Any'&&f.location!=='UK'&&p.location!==f.location)return false;if(f.minFollowers&&p.followers<f.minFollowers)return false;if(f.hasContact&&!p.has_contact)return false;if(f.analysisStatus&&p.analysis_status!==f.analysisStatus)return false;if(f.search){const hay=[p.name,p.handle,p.role,p.genre,p.location,p.contact_email,p.phone_number,p.website,p.notes,p.relationship_trend,p.analysis_status,...p.secondary_roles,...p.platforms].join(' ').toLowerCase();if(!hay.includes(f.search))return false}return true})}
  function createPerson(input){
    const source=text(input.source_url).slice(0,500),handle=text(input.handle).slice(0,120),email=cleanEmail(input.contact_email),phone=cleanPhone(input.phone_number||input.phone),name=text(input.name||handle||email||phone||'Captured profile').slice(0,120);if(!name)throw new Error('Name or handle required');
    let p=db.people.find(x=>(handle&&lower(x.handle)===lower(handle))||(source&&x.source_url===source)||(email&&lower(x.contact_email)===email)||(phone&&cleanPhone(x.phone_number)===phone));const ts=now();
    const incoming={name,handle,role:text(input.role||'Unknown').slice(0,80),secondary_roles:arr(input.secondary_roles).slice(0,10),genre:text(input.genre).slice(0,120),location:text(input.location).slice(0,120),followers:Math.max(0,Number(input.followers||0)||0),relationship:text(input.relationship||'Discovery').slice(0,50),contact_email:email,phone_number:phone,contact_type:text(input.contact_type).slice(0,80),website:text(input.website).slice(0,500),platforms:arr(input.platforms).slice(0,10),source_accounts:arr(input.source_accounts).slice(0,30),source_overlap:Math.max(0,Number(input.source_overlap||0)||0),network_score:clamp(input.network_score??50,0,100),engagement_score:clamp(input.engagement_score??0,0,100),last_interaction:text(input.last_interaction).slice(0,40),notes:text(input.notes).slice(0,3000),status:text(input.status||'Identified').slice(0,50),source_url:source,contact_source:text(input.contact_source).slice(0,500),classification_confidence:clamp(input.classification_confidence??0,0,100),analysis_status:text(input.analysis_status||'Imported').slice(0,50),analysis_confidence:clamp(input.analysis_confidence??input.classification_confidence??0,0,100),last_analysed_at:text(input.last_analysed_at).slice(0,40),updated_at:ts};
    if(p){
      for(const [k,v] of Object.entries(incoming)){
        if(k==='role'&&v==='Unknown'&&p.role&&p.role!=='Unknown')continue;if(k==='network_score'&&input.network_score===undefined)continue;if(k==='followers'&&Number(v)===0&&Number(p.followers)>0)continue;if(k==='relationship'&&(!input.relationship||v==='Discovery')&&p.relationship&&p.relationship!=='Discovery')continue;if(k==='notes'&&v&&p.notes&&p.notes!==v){p.notes=(p.notes+'\n'+v).slice(0,3000);continue}p[k]=mergeField(p[k],v);
      }
    }else{p={id:db.nextPersonId++,...incoming,created_at:ts};db.people.push(p)}
    save();return personView(p);
  }
  function analysePerson(p){
    const combined=[p.name,p.handle,p.role,p.genre,p.location,p.contact_email,p.phone_number,p.website,p.source_url,p.notes,...arr(p.platforms)].filter(Boolean).join(' | '),det=analyseTextLine(combined)||{};
    if((!p.role||p.role==='Unknown')&&det.role&&det.role!=='Unknown')p.role=det.role;if(!p.contact_email&&det.contact_email)p.contact_email=det.contact_email;if(!p.phone_number&&det.phone_number)p.phone_number=det.phone_number;if(!p.location&&det.location)p.location=det.location;if(!p.followers&&det.followers)p.followers=det.followers;if(!arr(p.platforms).length&&arr(det.platforms).length)p.platforms=det.platforms;p.analysis_confidence=Math.max(Number(p.analysis_confidence||0),Number(det.analysis_confidence||0));p.classification_confidence=Math.max(Number(p.classification_confidence||0),Number(det.classification_confidence||0));p.last_analysed_at=now();p.analysis_status=(p.contact_email||p.phone_number||p.website||p.source_url)?'Contact Ready':'Missing Details';p.network_score=opportunityScore(p);if(p.network_score>=78&&(p.contact_email||p.phone_number||p.website||p.source_url))p.analysis_status='Priority';p.updated_at=now();return p;
  }
  function batchAnalyse(input){
    const lines=String(input||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);let created=0,updated=0,skipped=0;const ids=[];
    for(const line of lines){try{const d=analyseTextLine(line);if(!d){skipped++;continue}const before=db.people.length;const p=createPerson(d);if(db.people.length>before)created++;else updated++;analysePerson(db.people.find(x=>x.id===p.id));ids.push(p.id)}catch{skipped++}}
    save();const people=ids.map(id=>personView(db.people.find(p=>p.id===id))).filter(Boolean);return {created,updated,skipped,total:people.length,emails:people.filter(p=>p.contact_email).length,phones:people.filter(p=>p.phone_number).length,roles:people.filter(p=>p.role&&p.role!=='Unknown').length,priority:people.filter(p=>p.analysis_status==='Priority').length,people};
  }
  function analyseAll(){db.people.forEach(analysePerson);save();const people=db.people.map(personView);return {total:people.length,emails:people.filter(p=>p.contact_email).length,phones:people.filter(p=>p.phone_number).length,roles:people.filter(p=>p.role&&p.role!=='Unknown').length,priority:people.filter(p=>p.analysis_status==='Priority').length,contactReady:people.filter(p=>p.analysis_status==='Contact Ready'||p.analysis_status==='Priority').length,missing:people.filter(p=>p.analysis_status==='Missing Details').length,people}}
  function intelligence(){const people=db.people.map(personView);return {total:people.length,imported:people.filter(p=>!p.last_analysed_at).length,analysed:people.filter(p=>p.last_analysed_at).length,emails:people.filter(p=>p.contact_email).length,phones:people.filter(p=>p.phone_number).length,contactReady:people.filter(p=>['Contact Ready','Priority'].includes(p.analysis_status)).length,priority:people.filter(p=>p.analysis_status==='Priority').sort((a,b)=>b.opportunity_score-a.opportunity_score),missing:people.filter(p=>p.analysis_status==='Missing Details').length,roles:people.reduce((a,p)=>{a[p.role||'Unknown']=(a[p.role||'Unknown']||0)+1;return a},{})}}
  function csv(){const headers=['id','name','handle','role','genre','location','followers','relationship','relationship_trend','contact_email','phone_number','website','network_score','opportunity_score','analysis_status','analysis_confidence','last_analysed_at','last_interaction','source_url','platforms','notes'];const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"';return [headers.join(','),...db.people.slice().map(personView).sort((a,b)=>b.opportunity_score-a.opportunity_score).map(p=>headers.map(h=>q(Array.isArray(p[h])?p[h].join(' | '):p[h])).join(','))].join('\n')}
  function nextMoves(){const rows=db.people.map(personView),moves=[];rows.filter(p=>p.interaction_count&&daysSince(p.last_interaction)>=14&&p.relationship!=='Discovery').sort((a,b)=>b.opportunity_score-a.opportunity_score).slice(0,3).forEach(p=>moves.push({type:'Reconnect',person_id:p.id,name:p.name,detail:`No interaction for ${daysSince(p.last_interaction)} days`,priority:p.opportunity_score}));rows.filter(p=>p.analysis_status==='Priority'&&!p.interaction_count).sort((a,b)=>b.opportunity_score-a.opportunity_score).slice(0,3).forEach(p=>moves.push({type:'Priority opportunity',person_id:p.id,name:p.name,detail:`Orbit IQ ${p.opportunity_score}`,priority:p.opportunity_score}));rows.filter(p=>p.has_contact&&!p.interaction_count&&p.opportunity_score>=60).sort((a,b)=>b.opportunity_score-a.opportunity_score).slice(0,2).forEach(p=>moves.push({type:'First contact',person_id:p.id,name:p.name,detail:'Contact route available',priority:p.opportunity_score}));return moves.sort((a,b)=>b.priority-a.priority).slice(0,5)}

  async function api(url,opts={}){
    const u=new URL(url,'https://crowd-orbit.local'),method=String(opts.method||'GET').toUpperCase(),b=body(opts),path=u.pathname;
    if(path==='/api/session')return {app:'Crowd Orbit',auth_required:false,authenticated:true,offline:true};if(path==='/api/login'||path==='/api/logout')return {ok:true};
    if(path==='/api/dashboard'){const rows=db.people.map(personView),roles={};rows.forEach(p=>roles[p.role]=(roles[p.role]||0)+1);const intel=intelligence();return {total:rows.length,contacts:rows.filter(p=>p.has_contact).length,warm:rows.filter(p=>p.relationship==='Warm').length,second:rows.filter(p=>p.relationship==='2nd degree').length,roles,top:rows.slice().sort((a,b)=>b.opportunity_score-a.opportunity_score).slice(0,5),next_moves:nextMoves(),goals:db.goals,intelligence:intel};}
    if(path==='/api/intelligence'&&method==='GET')return intelligence();if(path==='/api/analyse'&&method==='POST'){if(b.text!==undefined)return batchAnalyse(b.text);return analyseAll();}
    if(path==='/api/goals'&&method==='GET')return {goals:db.goals.slice()};if(path==='/api/goals'&&method==='POST'){db.goals=arr(b.goals).map(x=>String(x).slice(0,80)).filter(Boolean).slice(0,8);save();return {goals:db.goals.slice()}}
    if(path==='/api/people'&&method==='GET')return {people:filterPeople(db.people.slice().sort((a,b)=>opportunityScore(b)-opportunityScore(a)||b.followers-a.followers),filters(u.searchParams))};if(path==='/api/people'&&method==='POST')return {person:createPerson(b)};
    const pm=path.match(/^\/api\/people\/(\d+)$/);if(pm&&method==='PATCH'){const p=db.people.find(x=>x.id===Number(pm[1]));if(!p)throw new Error('Person not found');if('contact_email'in b)b.contact_email=cleanEmail(b.contact_email);if('phone_number'in b)b.phone_number=cleanPhone(b.phone_number);Object.assign(p,b,{updated_at:now()});analysePerson(p);save();return {person:personView(p)}}
    const im=path.match(/^\/api\/people\/(\d+)\/interactions$/);if(im&&method==='GET')return {interactions:db.interactions.filter(i=>i.person_id===Number(im[1])).sort((a,b)=>String(b.at).localeCompare(String(a.at)))};if(im&&method==='POST'){const p=db.people.find(x=>x.id===Number(im[1]));if(!p)throw new Error('Person not found');const i={id:db.nextInteractionId++,person_id:p.id,type:text(b.type||'Interaction').slice(0,50),note:text(b.note).slice(0,1000),at:text(b.at||now())};db.interactions.push(i);p.last_interaction=i.at;p.updated_at=now();if(p.relationship==='Discovery')p.relationship='2nd degree';save();return {interaction:i,person:personView(p)}}
    if(path==='/api/seeds'&&method==='GET')return {seeds:db.seeds.slice().sort((a,b)=>b.id-a.id)};if(path==='/api/seeds'&&method==='POST'){let h=text(b.handle);if(!h)throw new Error('Handle required');if(!h.startsWith('@'))h='@'+h;if(!db.seeds.some(s=>lower(s.handle)===lower(h)))db.seeds.push({id:db.nextSeedId++,handle:h,label:text(b.label).slice(0,120),created_at:now()});save();return {seeds:db.seeds.slice()}}
    const sm=path.match(/^\/api\/seeds\/(\d+)$/);if(sm&&method==='DELETE'){db.seeds=db.seeds.filter(s=>s.id!==Number(sm[1]));save();return {ok:true}}
    if(path==='/api/discover'&&method==='POST'){const q=new URLSearchParams();[['role',b.role],['relationship',b.relationship],['location',b.location],['minFollowers',b.minFollowers],['analysisStatus',b.analysisStatus]].forEach(([k,v])=>{if(v!==undefined&&v!==null)q.set(k,String(v))});if(b.hasContact)q.set('hasContact','1');let people=filterPeople(db.people,filters(q)).map(p=>({...p,match_score:score(p)}));if(Number(b.minOverlap||0))people=people.filter(p=>p.source_overlap>=Number(b.minOverlap));people.sort((a,c)=>c.match_score-a.match_score||c.opportunity_score-a.opportunity_score);return {mode:'offline',people,notice:'Ranked from profiles stored on this device.'}}
    if(path==='/api/campaigns'&&method==='POST'){const name=text(b.name);if(!name)throw new Error('Campaign name required');const c={id:db.nextCampaignId++,name,goal:text(b.goal||'general'),priority:text(b.priority||'best_overall'),status:'Draft',created_at:now(),updated_at:now()};db.campaigns.push(c);save();return {campaign:{...c}}}if(path==='/api/campaigns'&&method==='GET')return {campaigns:db.campaigns.slice().sort((a,b)=>b.id-a.id)};
    const rm=path.match(/^\/api\/campaigns\/(\d+)\/recommend$/);if(rm&&method==='POST'){const id=Number(rm[1]),c=db.campaigns.find(x=>x.id===id);if(!c)throw new Error('Campaign not found');let rows=db.people.map(personView);if(arr(b.personIds).length){const ids=new Set(arr(b.personIds).map(Number));rows=rows.filter(p=>ids.has(p.id))}const q=new URLSearchParams();[['role',b.role],['location',b.location],['minFollowers',b.minFollowers]].forEach(([k,v])=>{if(v!==undefined&&v!==null)q.set(k,String(v))});if(b.hasContact)q.set('hasContact','1');rows=filterPeople(rows,filters(q));const limit=clamp(b.limit||25,1,250);const people=rows.map(p=>({...p,campaign_score:score(p,c.goal,c.priority),reason:reason(p,c.goal)})).sort((a,z)=>z.campaign_score-a.campaign_score).slice(0,limit);people.forEach(p=>{let cp=db.campaignPeople.find(x=>x.campaign_id===id&&x.person_id===p.id);if(cp){cp.score=p.campaign_score;cp.reason=p.reason}else db.campaignPeople.push({campaign_id:id,person_id:p.id,score:p.campaign_score,reason:p.reason,contact_status:'Ready',last_contacted:''})});c.status='Active';c.updated_at=now();save();return {campaign:{...c},people}}
    const cm=path.match(/^\/api\/campaigns\/(\d+)\/people\/(\d+)$/);if(cm&&method==='PATCH'){let cp=db.campaignPeople.find(x=>x.campaign_id===Number(cm[1])&&x.person_id===Number(cm[2]));if(!cp){cp={campaign_id:Number(cm[1]),person_id:Number(cm[2]),score:0,reason:'',contact_status:'Ready',last_contacted:''};db.campaignPeople.push(cp)}Object.assign(cp,b);save();return {ok:true}}
    throw new Error('Local action not available');
  }
  function exportBackup(){return JSON.stringify({...db,exported_at:now(),app:'Crowd Orbit'},null,2)}
  function importBackup(payload){const d=JSON.parse(payload);if(!d||!Array.isArray(d.people)||!Array.isArray(d.seeds)||!Array.isArray(d.campaigns))throw new Error('This is not a valid Crowd Orbit backup');db={...blank(),...d,version:3,interactions:arr(d.interactions),goals:arr(d.goals).length?arr(d.goals):blank().goals};delete db.exported_at;delete db.app;db.people=db.people.map(p=>({...p,phone_number:text(p.phone_number||p.phone||''),analysis_status:p.analysis_status||'Imported',analysis_confidence:Number(p.analysis_confidence||p.classification_confidence||0)}));db.nextPersonId=Math.max(Number(db.nextPersonId)||1,...db.people.map(p=>Number(p.id||0)+1));db.nextSeedId=Math.max(Number(db.nextSeedId)||1,...db.seeds.map(s=>Number(s.id||0)+1));db.nextCampaignId=Math.max(Number(db.nextCampaignId)||1,...db.campaigns.map(c=>Number(c.id||0)+1));db.nextInteractionId=Math.max(Number(db.nextInteractionId)||1,...db.interactions.map(i=>Number(i.id||0)+1));save();return {people:db.people.length,campaigns:db.campaigns.length}}
  function reset(){db=blank();save()}function counts(){return {people:db.people.length,seeds:db.seeds.length,campaigns:db.campaigns.length,interactions:db.interactions.length}}
  window.CrowdOrbitLocalAPI={api,exportCSV:csv,exportBackup,importBackup,reset,counts,batchAnalyse,analyseAll,analyseTextLine};
})();
